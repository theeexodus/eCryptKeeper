import GeneratedCertificate from '@/components/GeneratedCertificate';
import Navbar from '@/components/Navbar';
import React from 'react';

const Issued: React.FC = () => {
  return (
    <>
<Navbar/>

   <GeneratedCertificate/>
    </>
  );
};

export default Issued;
